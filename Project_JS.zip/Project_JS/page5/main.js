const cartItems = [
    {
      title: "Introduction to User Experience Design",
      price: "$45.00",
      author: "John Doe",
      rating: "4.6",
      reviews: "250",
      totalHours: "22 Total Hours",
      lectures: "155 Lectures",
      level: "All levels",
      image: "https://via.placeholder.com/120x80"
    },
    {
      title: "Introduction to User Experience Design",
      price: "$45.00",
      author: "John Doe",
      rating: "4.6",
      reviews: "250",
      totalHours: "22 Total Hours",
      lectures: "155 Lectures",
      level: "All levels",
      image: "https://via.placeholder.com/120x80"
    },
    {
      title: "Introduction to User Experience Design",
      price: "$45.00",
      author: "John Doe",
      rating: "4.6",
      reviews: "250",
      totalHours: "22 Total Hours",
      lectures: "155 Lectures",
      level: "All levels",
      image: "https://via.placeholder.com/120x80"
    }
  ];

  const cartContainer = document.getElementById('cart-items');

  cartItems.forEach(item => {
    const cartItem = document.createElement('div');
    cartItem.className = 'cart-item';
    cartItem.innerHTML = `
      <img src="${item.image}" alt="${item.title}">
      <div class="cart-details">
        <h4>${item.title}</h4>
        <p>By ${item.author}</p>
        <p>${item.rating} ★ (${item.reviews} ratings) | ${item.totalHours} | ${item.lectures} | ${item.level}</p>
        <div class="cart-actions">
          <span onclick="saveForLater()">Save for later</span>
          <span onclick="removeItem()">Remove</span>
        </div>
      </div>
      <div class="cart-price">${item.price}</div>
    `;
    cartContainer.appendChild(cartItem);
  });

  function saveForLater() {
    alert('Item saved for later!');
  }

  function removeItem() {
    alert('Item removed from cart!');
  }

  function proceedToCheckout() {
    alert('Proceeding to checkout...');
  }