 document.querySelector('.sign-in-btn').addEventListener('click', () => {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (!email || !password) {
      alert('Please fill in all fields');
      return;
    }

    let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
let testEmail = "test@example.com";
console.log("Is valid email:", emailRegex.test(testEmail));


    console.log('Email:', email);
    console.log('Password:', password);
    alert('Sign-in successful!');
  });

  document.getElementById('facebook-login').addEventListener('click', () => {
    alert('Logging in with Facebook...');
  });

  document.getElementById('google-login').addEventListener('click', () => {
    alert('Logging in with Google...');
  });

  document.getElementById('microsoft-login').addEventListener('click', () => {
    alert('Logging in with Microsoft...');
  });
  