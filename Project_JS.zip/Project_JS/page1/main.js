let fullFooterInfo = `Contact us at ${footerEmail} or call us at ${phoneNumber}.`;

function updateHeader(message) {
    document.querySelector("h1").innerText = message;
  }
  updateHeader("Thank you for your order!");

  for (let i = 0; i < categoryList.length; i++) {
    console.log(`Category ${i + 1}: ${categoryList[i]}`);
  }
  
  let index = 0;
  while (index < categoryList.length) {
    console.log(`Category (while): ${categoryList[index]}`);
    index++;
  }
  
  contactInfo.website = "www.bywayedu.com";
  console.log("Updated Contact Info:", contactInfo);
  

  fetch("https://jsonplaceholder.typicode.com/posts")
  .then(response => response.json())
  .then(data => console.log("Fetched Data:", data));

  let jsonData = JSON.stringify(contactInfo);
let parsedData = JSON.parse(jsonData);
console.log("JSON Data:", jsonData, "Parsed Data:", parsedData);

$(document).ready(function () {
    $(".logo").css("color", "blue");
    $("footer").append("<p>Thank you for choosing Byway!</p>");
  });
  
