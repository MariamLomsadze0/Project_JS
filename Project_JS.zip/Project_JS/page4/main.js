function applyCoupon() {
    const couponCode = document.getElementById('coupon').value.trim();
    if (couponCode === 'DISCOUNT10') {
      document.getElementById('discount').innerText = '-$20.00';
      document.getElementById('total').innerText = '$280.00';
      alert('Coupon applied successfully!');
    } else {
      alert('Invalid coupon code!');
    }
  }

  function proceedToCheckout() {
    alert('Proceeding to checkout...');
  }